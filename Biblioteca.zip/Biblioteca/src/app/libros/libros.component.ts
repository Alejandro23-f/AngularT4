import { Component, OnInit } from '@angular/core';
import books from "../../assets/data.json";
import { Book } from '../../Book';
import { librosService } from './libros.service';


@Component({
  selector: 'app-libros',
  templateUrl: './libros.component.html',
  styleUrls: ['./libros.component.css']
})

 
export class LibrosComponent implements OnInit {

  
booksList : Book[]; 

  constructor(private bookService:librosService) {
    this.booksList = books;  
    
    
   }

  ngOnInit() { 
    this.bookService.getLibro().subscribe((book)=> {
      console.log(book)
      this.booksList.push(book)
    })
  }

  deletebook(id) {
    //delete this.booksList[id];
    this.booksList.splice(id,1)
    this.ngOnInit();
  }

  /*reciveBook($event) {  
    console.log('estoy en el receive')
    console.log(this.booksList)
    this.booksList.push($event);
    //console.log(this.booksList)
    //this.ngOnInit();
  } */ 


   
}
