import {Injectable} from '@angular/core'
import { Subject } from 'rxjs'
import { Book } from 'src/Book'

@Injectable({
    providedIn:'root'
})

export class librosService
{
    constructor(){}
    private libro = new Subject<Book> ()
    public setLibro(libro:Book)
    {
        this.libro.next(libro)
    }

    public getLibro()
    {
        return this.libro.asObservable()
    }
}