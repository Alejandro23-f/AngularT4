export class Book {
    id: Number;
    titulo: string;
    autor: string;
    descripcion:string;
  }